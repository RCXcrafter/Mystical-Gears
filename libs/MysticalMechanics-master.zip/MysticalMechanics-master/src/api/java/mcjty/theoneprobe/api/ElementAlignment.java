package mcjty.theoneprobe.api;

public enum ElementAlignment {
    ALIGN_TOPLEFT,
    ALIGN_CENTER,
    ALIGN_BOTTOMRIGHT
}
