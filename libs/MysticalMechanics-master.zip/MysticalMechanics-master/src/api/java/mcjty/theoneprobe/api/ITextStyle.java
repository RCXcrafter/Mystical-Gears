package mcjty.theoneprobe.api;

/**
 * Style for the text element.
 */
public interface ITextStyle {
}
