package betterwithmods.api.tile;

public interface ICrankable {
}
