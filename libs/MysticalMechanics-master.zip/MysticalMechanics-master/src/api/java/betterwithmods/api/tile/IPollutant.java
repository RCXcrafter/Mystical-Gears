package betterwithmods.api.tile;

public interface IPollutant {
    boolean isPolluting();

    float getPollutionRate();
}
