@API(apiVersion = "Beta 0.6", owner = "betterwithmods", provides = "BetterWithModsAPI")
package betterwithmods.api;

import net.minecraftforge.fml.common.API;