package betterwithmods.api;

import betterwithmods.api.util.IMechanicalUtil;

public class BWMAPI {
    public static IMechanicalUtil IMPLEMENTATION;
}
