@API(apiVersion = "0.1", owner = "mysticalmechanics", provides = "MysticalMechanicsAPI")
package mysticalmechanics.api;

import net.minecraftforge.fml.common.API;